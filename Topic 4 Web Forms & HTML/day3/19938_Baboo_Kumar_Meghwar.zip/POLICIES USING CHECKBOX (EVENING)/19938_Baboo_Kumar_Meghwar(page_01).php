<!DOCTYPE html>
<html>

<head>
    <title>Loop Example</title>
</head>

<body>
    <center>
        <h4>Policies Using CheckBox (Evening)</h4>
        <table>

            <form action="./19938_Baboo_Kumar_Meghwar(page_02).php" method="POST">
                <tr>
                    <td><label>Stipend</label></td>
                    <td><input type="checkbox" name="Stipend" /> </td>
                </tr>
                <tr>
                    <td><label>Disciplane</label></td>
                    <td><input type="checkbox" name="Disciplane" /> </td>
                </tr>
                <tr>
                    <td><label>Attendance</label></td>
                    <td><input type="checkbox" name="Attendance" /> </td>
                </tr>
                <tr>
                    <td><label>Assignment</label></td>
                    <td><input type="checkbox" name="Assignment" /> </td>
                </tr>
                <tr>
                    <td><label>Agree</label></td>
                    <td><input type="checkbox" name="Agree" /> </td>
                </tr>

                <tr>
                    <td><input type="submit" name="submit" value="submit " /> </td>
                </tr>

            </form>

        </table>
    </center>
</body>

</html>