<!DOCTYPE html>
<html>
    <head>
        <title>PHP Easy Tutorials</title>
    </head>
    <body>
        <!-- <h1>Asslam alikum sir i </h1> -->
       <a href="https://www.geeksforgeeks.org/php-tutorials/"> <img src="../IMAGES/gfg_logo.png" alt="Geek For Geek Logo" height="5%" width="5%" ></a>
   <center> <h1>Hello,  Welcome To HTML 5 Easy Tutorials</h1></center>
    <center><h4>These Are Contents of our Web Page</h4></center>
        <br>
        <br>

            <!-- <center> -->
            <ol>
               <a href="#heading1"><li>Introducation to HTML</li></a>
               <!-- <a href=""></a> -->
               <a href="#heading2"><li>HTML Basics</li></a>
               <!-- <a href="#heading3"><li>What are data types</li></a> -->
                <!-- <li></li> -->
            </ol>
        <!-- <a href="../IMAGES/HTML-Tutorial.png" height ="101%" width ="100%"></a> -->


            <br><br>
                <br><br>
                    <br><br>
                        <br><br>
            <center><p>**************************Easy HTML Tutorials**********************</p></center>
            <h1 id="heading1">Introducation to HTML</h1>
            <p>
               HTML stands for HyperText Markup Language. It is used to design web pages using the markup language. HTML is the combination of Hypertext and Markup language. Hypertext defines the link between the web pages and markup language defines the text document within the tag that define the structure of web pages.
            </p>
            <h1 id="heading2">HTML Basics</h1>
            <p>
                In this Tutorials, we will see the HTML Basics by understanding all the basic stuff of HTML coding. There are various tags that we must consider and include while starting to code in HTML. These tags help in the organization and basic formatting of elements in our script or web pages. These step-by-step procedures will guide you through the process of writing HTML
                <ul>
                    <li>Every HTML code must be enclosed between basic HTML tags. It begins with html and ends with </li>
                    <li>The head tag comes next which contains all the header information of the web page or documents like the title of the page and other miscellaneous information. This information is enclosed within the head tag which opens with head and ends with head. The contents will of this tag will be explained in the later sections of the course</li>
                    <li>We can mention the title of a web page using the title tag. This is header information and hence is mentioned within the header tags. The tag begins with title and ends with title</li>
                    <li>Next step is the most important of all the tags we have learned so far. The body tag contains the actual body of the page which will be visible to all the users. This opens with body and ends with also body tag. All content enclosed within this tag will be shown on the web page be it writings or images or audio or videos or even links. We will see later in the section how using various tags we may insert mentioned contents into our web pages</li>
                    </li>
                </ul>
            </p>
            <!-- <h1></h1> -->
            <!-- </center> -->
    </body>
</html>
