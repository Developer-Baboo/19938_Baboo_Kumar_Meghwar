<!DOCTYPE html>
<html>
    <head>
        <title>CSS Easy Tutorials</title>
    </head>
    <body>
       <a href="https://www.geeksforgeeks.org/php-tutorials/"><img src="../IMAGES/gfg_logo.png" alt="Geek For Geek Logo" height="5%" width="5%" ></a>
   <center> <h1>Hello,  Welcome To CSS 3 Easy Tutorials</h1></center>
    <center><h4>These Are Contents of our Web Page</h4></center>
        <br>
        <br>
            <ol>
               <a href="#heading1"><li>Introducation to CSS</li></a>
               <a href="#heading2"><li>What does CSS mean</li></a>
               <a href="#heading3"><li>How CSS is different from HTML?</li></a>
             
            </ol>
            <br><br>
                <br><br>
                    <br><br>
                        <br><br>
            <center><p>**************************Easy CSS 3 Tutorials**********************</p></center>
            <h1 id="heading1">Introducation to CSS 3</h1>
            <p>
              CSS (Cascading Style Sheets)is used to apply styles to web pages. Cascading Style Sheets are fondly referred to as CSS. It is used to make web pages presentable. The reason for using this is to simplify the process of making web pages presentable. It allows you to apply styles on web pages. More importantly, it enables you to do this independently of the HTML that makes up each web page
            </p>
            <h1 id="heading2">What does CSS mean</h1>
            <p>
               Tags for formatting a web page were never intended in HTML. HTML was established to define a web page’s content. The addition of tags like font and color attributes to HTML created a big problem for web developers. The creation of large websites, where fonts and color information were added to each page, became a time-consuming and costly procedure. CSS was established to address this issue. CSS eliminated the HTML page’s style formatting
            </p>
            <h1 id="heading3">How CSS is different from HTML?</h1>
            <p>
              <ul>
                <li>HTML is used to define a structure of a web page whereas CSS is used to style the web pages by using different styling features</li>
                <li>HTML consists of tags inside which text is enclosed and CSS consists of selectors and declaration blocks.</li>
                <li>CSS can be internal or external depending upon the requirement.</li>
                <li>We cannot use HTML inside a CSS sheet but we can use CSS inside an HTML document.</li>
                <li>CSS has comparatively higher backup and support than HTML.</li>
              </ul>
            </p>

    </body>
</html>
