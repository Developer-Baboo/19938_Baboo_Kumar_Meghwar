<!DOCTYPE html>
<html>
    <head>
        <title>Internal link assignment</title>
    </head>
    <body>
        
   <center> <h1>Hello,  Welcome To My Website</h1></center>
    <center><h4>What Do You Wanna Learn?</h4></center>
        <br>
        <br>

            <!-- <center> -->
                <ol>
                    <li><a href="./other pages/19938_Baboo_Kumar_Meghwar (page_1).php">PHP</a></li> <br>
                    <li><a href="./other pages/19938_Baboo_Kumar_Meghwar (page_2).php">HTML 5</a></li> <br>
                    <li><a href="./other pages/19938_Baboo_Kumar_Meghwar (page_3).php">CSS 3</a></li> <br>
                </ol>
            <!-- </center> -->
    </body>
</html>