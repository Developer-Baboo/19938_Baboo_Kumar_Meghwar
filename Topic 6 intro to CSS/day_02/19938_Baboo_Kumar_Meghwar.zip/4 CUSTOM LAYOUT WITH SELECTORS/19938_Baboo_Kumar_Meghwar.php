<!Doctype html>
<html>

<head>
    <title>CUSTOM LAYOUT WITH SELECTORS</title>
    <link rel="stylesheet" href="./mystyle.css">
</head>

<body>
    <div style="border:2px solid blue; color:skyblue; font-size:30px " class="row">
        <div class="col-12">
            <center>
                <p>Image Here</p>
            </center>
        </div>
    </div>
    <div class="row">
        <div style="border:2px solid brown; " class="col-3">
            <div style="border:3px solid green; color:green">
                <center>
                    <h1>Menu <br> Here</h1>
                </center>
            </div>
            <br>
            <div style="border:4px solid #e8e5e8; color:#e8e5e8;font-size:30px">
                <center>
                    <h5>Some Content Here</h1>
                </center>
            </div>
        </div>
        <div class=" col-6">
            <div style="border:2px solid grey;">
                <center>
                    <p> <b>Simple</b> Menu Here</p>
                </center>
            </div>
            <br>
            <div style="border:4px solid red; color:red;  margin-right:50px; margin-left:50px ">
                <center>
                    <h1>Image <br> here </h1>
                </center>
            </div>
            <br>
            <div style="border:4px solid red; color:red; margin-right:50px; margin-left:50px">
                <center>
                    <h1>Image <br> here </h1>
                </center>
            </div>
            <center style="color:red; font-size:40px">
                <p>Some Content in this area</p>
            </center>
        </div>
        <div style="border:2px solid brown;" class="col-3">
            <div style="border:3px solid orange; color:skyblue">
                <center>
                    <h1>Login-form</h1>
                </center>
                <div style="border:3px solid skyblue; color:skyblue; font-size:20px; font-weight:bold;  margin:5px">
                    <center>
                        <p>User Name</p>
                    </center>
                </div>
                <div style="border:3px solid skyblue; color:skyblue; font-size:20px; font-weight:bold; margin:5px  ">
                    <center>
                        <p>Password</p>
                    </center>
                </div>
                <div style="border:3px solid skyblue; color:skyblue;font-size:20px; font-weight:bold;  margin:5px">
                    <center>
                        <p>Submit</p>
                    </center>
                </div>
            </div>
            <br>
            <div style="border:4px solid #e8e5e8; color:#e8e5e8; font-size:30px">
                <center>
                    <p>Some Content Here</p>
                </center>
            </div>
        </div>
    </div>
    <!-- <br> <br> -->
    <!-- <div style="background-color: grey;" class="row">
        <center>
            <h5>Footer Copyright Here</h5>
        </center>
    </div> -->
    <center style=" color:#a86eab; border:3px solid #a86eab; ">
        <h3>Footer Copyright Here</h3>
    </center>
</body>

</html>