<!Doctype html>
<html>

<head>
    <title>.::WEB PAGE LAYOUT DESIGN::.</title>
    <link rel="stylesheet" href="./mystyle.css">
</head>

<body style="background-color: lightblue;font-family:Georgia, 'Times New Roman', Times, serif ">
    <center><h1 style="background-color:darkgray; padding: 10px; text-shadow: 0 0 10px #FF0000; ">Our Projects</h1>
    </center>
    <div class="row">
        <div style="background-color:aqua" class="col-4">
            <center>
                <h2 style="text-shadow: 2px 2px red;">Facebook Login</h2>
            </center>
            <p>
                <img style="border-radius: 10px;" src="./images/facebook.PNG" alt="" height="10%" width="100%">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium odio commodi soluta, molestias ipsum debitis dolorum corporis totam vero, ad sit quae. Id nesciunt, deserunt maxime quidem consequatur dolore magni?
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium odio commodi soluta, molestias ipsum debitis dolorum corporis totam vero, ad sit quae. Id nesciunt, deserunt maxime quidem consequatur dolore magni?

            </p>
        </div>

        <div style="background-color:lightgreen; margin-right:20px; margin-left: 20px;  " class="col-4">
            <center>
                <h2 style="color: white;
  text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;">Stop Watch</h2>
            </center>
            <img style="border-radius: 10px;" src="./images/Capture.PNG" height="27%" width="100%" alt="">
            <p>
                Lorem ipsum dolor sit amet conse ctetur, adipi sicing elit. Est bland itiis reici endis volup tatum velit, ab alias aper iam facilis earum neque ullam quae, iusto fugiat, conseq uatur, quidem num quam volup tates iure min ima? Com modi.
            </p>
        </div>
        <div style="background-color:aliceblue" class="col-4">
            <center>
                <h2 style="color: white;text-shadow: 2px 2px 4px #000000;">Login Form</h2>
            </center>
            <img style="border-radius: 10px;" src="./images/saylani.PNG" height="27%" width="100%" alt="">
            <p>
                Lorem ipsum dolor sit amet conse ctetur, adipi sicing elit. Est bland itiis reici endis volup tatum velit, ab alias aper iam facilis earum neque ullam quae, iusto fugiat, conseq uatur, quidem num quam volup tates iure min ima? Com modi.
            </p>
        </div>
        <br>



    </div>
    <div style="background-color:burlywood; margin:0px" class="col-12">
        <center>
            <footer>
                <center>
                    <p>
                        Copyright Hidaya Institue of Science & Technology
                    </p>
                </center>
            </footer>
        </center>
    </div>
</body>

</html>