<!Doctype html>
<html>

<head>
    <title>.::WEB PAGE LAYOUT DESIGN::.</title>
    <link rel="stylesheet" href="./mystyle.css">
</head>

<body style="background-color: lightblue;font-family:Georgia, 'Times New Roman', Times, serif ">

    <ul class="main-navigation">
        <li><a href="#">Products</a></li>
        <li><a href="#">Resource</a></li>
        <li><a href="#">Inspiration</a></li>
    </ul>
    <center>
        <h1 style="background-color:aquamarine; padding: p9x;">Our Story</h1>
    </center>
    <center>
        <div class="row">
            <img style="text-align:center" ; src="./images/11.PNG" alt="">
        </div>
    </center>
    <p class="col-12">
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint, dolore? Enim consequuntur velit et vel consequatur, provident modi repellat cumque nobis maxime ut molestiae, totam rerum vitae itaque in eaque!
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint, dolore? Enim consequuntur velit et vel consequatur, provident modi repellat cumque nobis maxime ut molestiae, totam rerum vitae itaque in eaque! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint, dolore? Enim consequuntur velit et vel consequatur, provident modi repellat cumque nobis maxime ut molestiae, totam rerum vitae itaque in eaque! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint, dolore? Enim consequuntur velit et vel consequatur, provident modi repellat cumque nobis maxime ut molestiae, totam rerum vitae itaque in eaque! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint, dolore? Enim consequuntur velit et vel consequatur, provident modi repellat cumque nobis maxime ut molestiae, totam rerum vitae itaque in eaque! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint, dolore? Enim consequuntur velit et vel consequatur, provident modi repellat cumque nobis maxime ut molestiae, totam rerum vitae itaque in eaque! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint, dolore? Enim consequuntur velit et vel consequatur, provident modi repellat cumque nobis maxime ut molestiae, totam rerum vitae itaque in eaque! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint, dolore? Enim consequuntur velit et vel consequatur, provident modi repellat cumque nobis maxime ut molestiae, totam rerum vitae itaque in eaque! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint, dolore? Enim consequuntur velit et vel consequatur, provident modi repellat cumque nobis maxime ut molestiae, totam rerum vitae itaque in eaque!
    </p>
    <footer>
        <center>
            <p style="background-color:grey;padding:10px">
                Copyright Developer Baboo Kumar Meghwar id: 19938
            </p>
        </center>
    </footer>
</body>

</html>